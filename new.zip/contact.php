<!DOCTYPE HTML>
<html lang="en">
  
<head>
    <title>Travel Mate - Contact</title>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet"/>
    <link rel="stylesheet" href="css/font-awesome.css"/>
    <link rel="stylesheet" href="css/lineicons.css"/>
    <link rel="stylesheet" href="css/weather-icons.css"/>
    <link rel="stylesheet" href="css/bootstrap.css"/>
    <link rel="stylesheet" href="css/styles.css"/>
  </head>
  <body>
    <nav class="navbar navbar-default navbar-inverse navbar-theme navbar-theme-abs navbar-theme-transparent navbar-theme-border" id="main-nav">
      <div class="container">
        <div class="navbar-inner nav">
          <div class="navbar-header">
            <button class="navbar-toggle collapsed" data-target="#navbar-main" data-toggle="collapse" type="button" area-expanded="false">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.html">
              <img src="img/logo.png" alt="Image Alternative text" title="Image Title"/>
            </a>
          </div>
          <div class="collapse navbar-collapse" id="navbar-main">
            <ul class="nav navbar-nav">
              <li class="active dropdown">
                <a class="dropdown-toggle" href="index.html" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Pages</a>
                <div class="dropdown-menu dropdown-menu-lg">
                  <div class="row">
                    <div class="col-md-4">
                      <h5 class="dropdown-meganav-list-title">Homepages</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="index.html">Index 1</a>
                        </li>
                        <li>
                          <a href="index-2.html">Index 2</a>
                        </li>
                        <li>
                          <a href="index-3.html">Index 3</a>
                        </li>
                        <li>
                          <a href="index-4.html">Index 4</a>
                        </li>
                        <li>
                          <a href="index-5.html">Index 5</a>
                        </li>
                        <li>
                          <a href="index-6.html">Index 6</a>
                        </li>
                        <li>
                          <a href="index-7.html">Index 7</a>
                        </li>
                        <li>
                          <a href="index-8.html">Index 8</a>
                        </li>
                        <li>
                          <a href="index-9.html">Index 9</a>
                        </li>
                        <li>
                          <a href="index-10.html">Index 10</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-4">
                      <h5 class="dropdown-meganav-list-title">Misc</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="blog.html">Blog</a>
                        </li>
                        <li>
                          <a href="blog-post.html">Blog Post</a>
                        </li>
                        <li>
                          <a href="404.html">404</a>
                        </li>
                        <li>
                          <a href="about-us.html">About Us</a>
                        </li>
                        <li>
                          <a href="contact.html">Contact</a>
                        </li>
                        <li>
                          <a href="login.html">Login</a>
                        </li>
                        <li>
                          <a href="login-2.html">Login 2</a>
                        </li>
                        <li>
                          <a href="register.html">Register</a>
                        </li>
                        <li>
                          <a href="pwd-reset.html">Reset password</a>
                        </li>
                        <li>
                          <a href="payment-success.html">Sucess Payment</a>
                        </li>
                        <li>
                          <a href="coming-soon.html">Coming Soon</a>
                        </li>
                        <li>
                          <a href="loading.html">Loading</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-4">
                      <h5 class="dropdown-meganav-list-title">Country/City</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="index-city-1.html">Index City 1</a>
                        </li>
                        <li>
                          <a href="index-city-2.html">Index City 2</a>
                        </li>
                        <li>
                          <a href="index-city-3.html">Index City 3</a>
                        </li>
                        <li>
                          <a href="index-country-1.html">Index Country 1</a>
                        </li>
                        <li>
                          <a href="index-country-2.html">Index Country 2</a>
                        </li>
                        <li>
                          <a href="index-country-3.html">Index Country 3</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </li>
              <li class="dropdown">
                <a class="dropdown-toggle" href="hotel-index-1.html" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Hotels</a>
                <div class="dropdown-menu dropdown-menu-xl">
                  <div class="row">
                    <div class="col-md-3">
                      <h5 class="dropdown-meganav-list-title">Homepages</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="hotel-index-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="hotel-index-2.html">Layout 2</a>
                        </li>
                        <li>
                          <a href="hotel-index-3.html">Layout 3</a>
                        </li>
                        <li>
                          <a href="hotel-index-4.html">Layout 4</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <h5 class="dropdown-meganav-list-title">Search Results</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="hotel-results-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="hotel-results-2.html">Layout 2</a>
                        </li>
                        <li>
                          <a href="hotel-results-3.html">Layout 3</a>
                        </li>
                        <li>
                          <a href="hotel-results-4.html">Layout 4</a>
                        </li>
                        <li>
                          <a href="hotel-results-5.html">Layout 5</a>
                        </li>
                        <li>
                          <a href="hotel-results-6.html">Layout 6</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <h5 class="dropdown-meganav-list-title">Hotel Pages</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="hotel-page-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="hotel-page-2.html">Layout 2</a>
                        </li>
                        <li>
                          <a href="hotel-page-3.html">Layout 3</a>
                        </li>
                        <li>
                          <a href="hotel-page-4.html">Layout 4</a>
                        </li>
                        <li>
                          <a href="hotel-page-5.html">Layout 5</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <h5 class="dropdown-meganav-list-title">Payment</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="hotel-payment-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="hotel-payment-2.html">Layout 2</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </li>
              <li class="dropdown">
                <a class="dropdown-toggle" href="room-index-1.html" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Rooms</a>
                <div class="dropdown-menu dropdown-menu-xl">
                  <div class="row">
                    <div class="col-md-3">
                      <h5 class="dropdown-meganav-list-title">Homepages</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="room-index-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="room-index-2.html">Layout 2</a>
                        </li>
                        <li>
                          <a href="room-index-3.html">Layout 3</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <h5 class="dropdown-meganav-list-title">Search Results</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="room-results-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="room-results-2.html">Layout 2</a>
                        </li>
                        <li>
                          <a href="room-results-3.html">Layout 3</a>
                        </li>
                        <li>
                          <a href="room-results-4.html">Layout 4</a>
                        </li>
                        <li>
                          <a href="room-results-5.html">Layout 5</a>
                        </li>
                        <li>
                          <a href="room-results-6.html">Layout 6</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <h5 class="dropdown-meganav-list-title">Room Pages</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="room-page-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="room-page-2.html">Layout 2</a>
                        </li>
                        <li>
                          <a href="room-page-3.html">Layout 3</a>
                        </li>
                        <li>
                          <a href="room-page-4.html">Layout 4</a>
                        </li>
                        <li>
                          <a href="room-page-5.html">Layout 5</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <h5 class="dropdown-meganav-list-title">Payment</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="room-payment-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="room-payment-2.html">Layout 2</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </li>
              <li class="dropdown">
                <a class="dropdown-toggle" href="flight-index-1.html" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Flights</a>
                <div class="dropdown-menu dropdown-menu-lg">
                  <div class="row">
                    <div class="col-md-4">
                      <h5 class="dropdown-meganav-list-title">Homepages</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="flight-index-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="flight-index-2.html">Layout 2</a>
                        </li>
                        <li>
                          <a href="flight-index-3.html">Layout 3</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-4">
                      <h5 class="dropdown-meganav-list-title">Search Results</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="flight-results-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="flight-results-2.html">Layout 2</a>
                        </li>
                        <li>
                          <a href="flight-results-3.html">Layout 3</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-4">
                      <h5 class="dropdown-meganav-list-title">Payment</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="flight-payment-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="flight-payment-2.html">Layout 2</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </li>
              <li class="dropdown">
                <a class="dropdown-toggle" href="car-index-1.html" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Cars</a>
                <div class="dropdown-menu dropdown-menu-lg">
                  <div class="row">
                    <div class="col-md-4">
                      <h5 class="dropdown-meganav-list-title">Homepages</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="car-index-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="car-index-2.html">Layout 2</a>
                        </li>
                        <li>
                          <a href="car-index-3.html">Layout 3</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-4">
                      <h5 class="dropdown-meganav-list-title">Search Results</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="car-results-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="car-results-2.html">Layout 2</a>
                        </li>
                        <li>
                          <a href="car-results-3.html">Layout 3</a>
                        </li>
                        <li>
                          <a href="car-results-4.html">Layout 4</a>
                        </li>
                        <li>
                          <a href="car-results-5.html">Layout 5</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-4">
                      <h5 class="dropdown-meganav-list-title">Payment</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="car-payment-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="car-payment-2.html">Layout 2</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </li>
              <li class="dropdown">
                <a class="dropdown-toggle" href="exp-index-1.html" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Experiences</a>
                <div class="dropdown-menu dropdown-menu-xl">
                  <div class="row">
                    <div class="col-md-3">
                      <h5 class="dropdown-meganav-list-title">Homepages</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="exp-index-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="exp-index-2.html">Layout 2</a>
                        </li>
                        <li>
                          <a href="exp-index-3.html">Layout 3</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <h5 class="dropdown-meganav-list-title">Search Results</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="exp-results-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="exp-results-2.html">Layout 2</a>
                        </li>
                        <li>
                          <a href="exp-results-3.html">Layout 3</a>
                        </li>
                        <li>
                          <a href="exp-results-4.html">Layout 4</a>
                        </li>
                        <li>
                          <a href="exp-results-5.html">Layout 5</a>
                        </li>
                        <li>
                          <a href="exp-results-6.html">Layout 6</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <h5 class="dropdown-meganav-list-title">Event Pages</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="exp-page-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="exp-page-2.html">Layout 2</a>
                        </li>
                        <li>
                          <a href="exp-page-3.html">Layout 3</a>
                        </li>
                        <li>
                          <a href="exp-page-4.html">Layout 4</a>
                        </li>
                        <li>
                          <a href="exp-page-5.html">Layout 5</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <h5 class="dropdown-meganav-list-title">Payment</h5>
                      <ul class="dropdown-meganav-list-items">
                        <li>
                          <a href="exp-payment-1.html">Layout 1</a>
                        </li>
                        <li>
                          <a href="exp-payment-2.html">Layout 2</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
              <li class="dropdown">
                <a class="dropdown-toggle" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                  <span class="_desk-h">Currency</span>
                  <b>USD</b>
                </a>
                <div class="dropdown-menu dropdown-menu-xxl">
                  <h5 class="dropdown-meganav-select-list-title">Popular Currencies</h5>
                  <div class="row" data-gutter="10">
                    <div class="col-md-3">
                      <ul class="dropdown-meganav-select-list-currency">
                        <li>
                          <a href="#">
                            <span>€</span>Euro
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>£</span>Pound sterling
                          </a>
                        </li>
                        <li class="active">
                          <a href="#">
                            <span>US$</span>U.S. dollar
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <ul class="dropdown-meganav-select-list-currency">
                        <li>
                          <a href="#">
                            <span>CAD</span>Canadian dollar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>AUD</span>Australian dollar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>RUB</span>Russian Ruble
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <ul class="dropdown-meganav-select-list-currency">
                        <li>
                          <a href="#">
                            <span>S$</span>Singapore dollar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>CNY</span>Chinese yuan
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>¥</span>Japanese yen
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <hr/>
                  <h5 class="dropdown-meganav-select-list-title">All Currencies</h5>
                  <div class="row" data-gutter="10">
                    <div class="col-md-3">
                      <ul class="dropdown-meganav-select-list-currency">
                        <li>
                          <a href="#">
                            <span>AR$</span>Argentine peso
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>AUD</span>Australian dollar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>AZN</span>Azerbaijan, New Ma...
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>BHD</span>Bahrain dinar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>BRL</span>Brazilian real
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>BGN</span>Bulgarian lev
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>CAD</span>Canadian dollar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>XOF</span>CFA Franc BCEAO
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>CL$</span>Chilean peso
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>CNY</span>Chinese yuan
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>COP</span>Colombian peso
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>Kč</span>Czech koruna
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>DKK</span>Danish krone
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <ul class="dropdown-meganav-select-list-currency">
                        <li>
                          <a href="#">
                            <span>EGP</span>Egyptian pound
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>€</span>Euro
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>FJD</span>Fijian dollar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>GEL</span>Georgian lari
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>HK$</span>Hong Kong Dollar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>HUF</span>Hungarian forint
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>Rs.</span>Indian rupee
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>Rp</span>Indonesian rupiah
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>₪</span>Israeli new sheqel
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>¥</span>Japanese yen
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>JOD</span>Jordanian dinar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>KZT</span>Kazakhstani tenge
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>KRW</span>Korean won
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <ul class="dropdown-meganav-select-list-currency">
                        <li>
                          <a href="#">
                            <span>KWD</span>Kuwaiti dinar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>MYR</span>Malaysian ringgit
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>MXN</span>Mexican peso
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>MDL</span>Moldovan leu
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>NAD</span>Namibian Dollar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>TWD</span>New Taiwan Dollar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>NZD</span>New Zealand dollar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>NOK</span>Norwegian krone
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>OMR</span>Omani rial
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>zł</span>Polish zloty
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>£</span>Pound sterling
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>QAR</span>Qatar riyal
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>lei</span>Romanian new leu
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <ul class="dropdown-meganav-select-list-currency">
                        <li>
                          <a href="#">
                            <span>RUB</span>Russian Ruble
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>SAR</span>Saudi Arabian riyal
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>S$</span>Singapore dollar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>ZAR</span>South African rand
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>SEK</span>Swedish krona
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>CHF</span>Swiss franc
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>THB</span>Thai baht
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>TL</span>Turkish lira
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>AED</span>U.A.E. dirham
                          </a>
                        </li>
                        <li class="active">
                          <a href="#">
                            <span>US$</span>U.S. dollar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>UAH</span>Ukraine Hryvnia
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <span>UZS</span>Uzbekistan, Sums
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </li>
              <li class="dropdown">
                <a class="dropdown-toggle" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                  <span class="_desk-h">Language</span>
                  <img class="navbar-flag" src="img/flags/USA.png" alt="Image Alternative text" title="Image Title"/>
                </a>
                <div class="dropdown-menu dropdown-menu-xxl">
                  <h5 class="dropdown-meganav-select-list-title">Languages</h5>
                  <div class="row" data-gutter="10">
                    <div class="col-md-3">
                      <ul class="dropdown-meganav-select-list-lang">
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/UK.png" alt="Image Alternative text" title="Image Title"/>English(UK)
                          </a>
                        </li>
                        <li class="active">
                          <a href="#">
                            <img src="img/flag_codes/US.png" alt="Image Alternative text" title="Image Title"/>English(US)
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/DE.png" alt="Image Alternative text" title="Image Title"/>Deutsch
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/NED.png" alt="Image Alternative text" title="Image Title"/>Nederlands
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/FR.png" alt="Image Alternative text" title="Image Title"/>Français
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/SP.png" alt="Image Alternative text" title="Image Title"/>Español
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/ARG.png" alt="Image Alternative text" title="Image Title"/>Español (AR)
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/IT.png" alt="Image Alternative text" title="Image Title"/>Italiano
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/PT.png" alt="Image Alternative text" title="Image Title"/>Português (PT)
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/BR.png" alt="Image Alternative text" title="Image Title"/>Português (BR)
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/NR.png" alt="Image Alternative text" title="Image Title"/>Norsk
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <ul class="dropdown-meganav-select-list-lang">
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/FIN.png" alt="Image Alternative text" title="Image Title"/>Suomi
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/SW.png" alt="Image Alternative text" title="Image Title"/>Svenska
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/DEN.png" alt="Image Alternative text" title="Image Title"/>Dansk
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/CZ.png" alt="Image Alternative text" title="Image Title"/>Čeština
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/HUN.png" alt="Image Alternative text" title="Image Title"/>Magyar
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/ROM.png" alt="Image Alternative text" title="Image Title"/>Română
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/JP.png" alt="Image Alternative text" title="Image Title"/>日本語
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/CN.png" alt="Image Alternative text" title="Image Title"/>简体中文
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/PL.png" alt="Image Alternative text" title="Image Title"/>Polski
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/GR.png" alt="Image Alternative text" title="Image Title"/>Ελληνικά
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/RU.png" alt="Image Alternative text" title="Image Title"/>Русский
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <ul class="dropdown-meganav-select-list-lang">
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/TUR.png" alt="Image Alternative text" title="Image Title"/>Türkçe
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/BUL.png" alt="Image Alternative text" title="Image Title"/>Български
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/ARB.png" alt="Image Alternative text" title="Image Title"/>العربية
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/KOR.png" alt="Image Alternative text" title="Image Title"/>한국어
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/ISR.png" alt="Image Alternative text" title="Image Title"/>עברית
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/LAT.png" alt="Image Alternative text" title="Image Title"/>Latviski
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/UKR.png" alt="Image Alternative text" title="Image Title"/>Українська
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/IND.png" alt="Image Alternative text" title="Image Title"/>Bahasa Indonesia
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/MAL.png" alt="Image Alternative text" title="Image Title"/>Bahasa Malaysia
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/TAI.png" alt="Image Alternative text" title="Image Title"/>ภาษาไทย
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/EST.png" alt="Image Alternative text" title="Image Title"/>Eesti
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <ul class="dropdown-meganav-select-list-lang">
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/CRO.png" alt="Image Alternative text" title="Image Title"/>Hrvatski
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/LIT.png" alt="Image Alternative text" title="Image Title"/>Lietuvių
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/SLO.png" alt="Image Alternative text" title="Image Title"/>Slovenčina
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/SERB.png" alt="Image Alternative text" title="Image Title"/>Srpski
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/SLOVE.png" alt="Image Alternative text" title="Image Title"/>Slovenščina
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/NAM.png" alt="Image Alternative text" title="Image Title"/>Tiếng Việt
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/PHI.png" alt="Image Alternative text" title="Image Title"/>Filipino
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <img src="img/flag_codes/ICE.png" alt="Image Alternative text" title="Image Title"/>Íslenska
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </li>
              <li class="navbar-nav-item-user dropdown">
                <a class="dropdown-toggle" href="account.html" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                  <i class="fa fa-user-circle-o navbar-nav-item-user-icon"></i>My Account
                </a>
                <ul class="dropdown-menu">
                  <li>
                    <a href="account.html">Preferences</a>
                  </li>
                  <li>
                    <a href="account-notifications.html">Notifications</a>
                  </li>
                  <li>
                    <a href="account-cards.html">Payment Methods</a>
                  </li>
                  <li>
                    <a href="account-travelers.html">Travelers</a>
                  </li>
                  <li>
                    <a href="account-history.html">History</a>
                  </li>
                  <li>
                    <a href="account-bookmarks.html">Bookmarks</a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
    <div class="theme-hero-area _h-50vh _h-mob-80vh theme-hero-area-sm">
      <div class="theme-hero-area-bg-wrap">
        <div class="theme-hero-area-bg" style="background-image:url(img/man-wearing-red-while-sitting-inside-concrete-bulding-7065_1500x800.jpg);"></div>
        <div class="theme-hero-area-mask theme-hero-area-mask-half"></div>
        <div class="theme-hero-area-inner-shadow"></div>
      </div>
      <div class="theme-hero-area-body">
        <div class="container">
          <div class="row">
            <div class="col-md-8 col-md-offset-2 theme-page-header-abs">
              <div class="theme-page-header theme-page-header-lg">
                <h1 class="theme-page-header-title">Headquarters</h1>
                <div class="theme-contact-info">
                  <div class="row row-no-gutter">
                    <div class="col-md-3">
                      <address class="theme-contact-address">21 Chipmunk Lane
                        <br/>Old Town
                        <br/>Maine 04468
                      </address>
                    </div>
                    <div class="col-md-4">
                      <ul class="theme-contact-info-list">
                        <li>
                          <i class="fa fa-phone"></i>207-827-5358
                        </li>
                        <li>
                          <a href="#">
                            <i class="fa fa-envelope"></i>hello@Bookify.com
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="theme-page-section theme-page-section-xl theme-page-section-gray">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-offset-2">
            <div class="theme-contact">
              <h2 class="theme-contact-title">Contact Us</h2>
              <div class="row row-col-mob-gap">
                <div class="col-md-7">
                  <div class="form-group theme-contact-form-group">
                    <input class="form-control" type="text" placeholder="Name"/>
                  </div>
                  <div class="form-group theme-contact-form-group">
                    <input class="form-control" type="text" placeholder="Email"/>
                  </div>
                  <div class="form-group theme-contact-form-group">
                    <textarea class="form-control" rows="5" placeholder="Message"></textarea>
                  </div>
                  <a class="btn btn-uc btn-primary btn-lg" href="#">Send Your Message</a>
                </div>
                <div class="col-md-5">
                  <div class="google-map theme-contact-map" data-lat="40.7483624" data-lng="-73.9900896" data-tab="false"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="theme-footer" id="mainFooter">
      <div class="container _ph-mob-0">
        <div class="row row-eq-height row-mob-full" data-gutter="60">
          <div class="col-md-3">
            <div class="theme-footer-section theme-footer-">
              <a class="theme-footer-brand _mb-mob-30" href="#">
                <img src="img/logo-black.png" alt="Image Alternative text" title="Image Title"/>
              </a>
              <div class="theme-footer-brand-text">
                <p>Nulla euismod euismod urna donec mollis eleifend molestie sociosqu mauris augue mattis a tellus ipsum</p>
                <p>Nec nunc ornare sociis leo nisi venenatis nunc ultrices platea commodo sociosqu himenaeos posuere ipsum</p>
              </div>
            </div>
          </div>
          <div class="col-md-5">
            <div class="row">
              <div class="col-md-4">
                <div class="theme-footer-section theme-footer-">
                  <h5 class="theme-footer-section-title">Travel Mate</h5>
                  <ul class="theme-footer-section-list">
                    <li>
                      <a href="#">About Travel Mate</a>
                    </li>
                    <li>
                      <a href="#">Mobile App</a>
                    </li>
                    <li>
                      <a href="#">Customer Support</a>
                    </li>
                    <li>
                      <a href="#">Advertising</a>
                    </li>
                    <li>
                      <a href="#">Jobs</a>
                    </li>
                    <li>
                      <a href="#">Privacy Policy</a>
                    </li>
                    <li>
                      <a href="#">Terms of Use</a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-md-4">
                <div class="theme-footer-section theme-footer-">
                  <h5 class="theme-footer-section-title">Explore</h5>
                  <ul class="theme-footer-section-list">
                    <li>
                      <a href="#">Countries</a>
                    </li>
                    <li>
                      <a href="#">Regions</a>
                    </li>
                    <li>
                      <a href="#">Cities</a>
                    </li>
                    <li>
                      <a href="#">Districs</a>
                    </li>
                    <li>
                      <a href="#">Airports</a>
                    </li>
                    <li>
                      <a href="#">Hotels</a>
                    </li>
                    <li>
                      <a href="#">Places of Interest</a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-md-4">
                <div class="theme-footer-section theme-footer-">
                  <h5 class="theme-footer-section-title">Book</h5>
                  <ul class="theme-footer-section-list">
                    <li>
                      <a href="#">Apartments</a>
                    </li>
                    <li>
                      <a href="#">Resorts</a>
                    </li>
                    <li>
                      <a href="#">Villas</a>
                    </li>
                    <li>
                      <a href="#">Hostels</a>
                    </li>
                    <li>
                      <a href="#">B&Bs</a>
                    </li>
                    <li>
                      <a href="#">Guesthouses</a>
                    </li>
                    <li>
                      <a href="#">Hotel Chains</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="theme-footer-section theme-footer-section-subscribe bg-grad _mt-mob-30">
              <div class="theme-footer-section-subscribe-bg" style="background-image:url(img/footer/footer_subscribe_bg.png);"></div>
              <div class="theme-footer-section-subscribe-content">
                <h5 class="theme-footer-section-title">Save up to 50% off your next trip</h5>
                <p class="text-muted">Subscribe to unlock our secret deals</p>
                <form>
                  <div class="form-group">
                    <input class="form-control theme-footer-subscribe-form-control" type="email" placeholder="Type your e-mail here"/>
                  </div>
                  <button class="btn btn-primary-invert btn-shadow text-upcase theme-footer-subscribe-btn" type="submit">Get deals</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="theme-copyright">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <p class="theme-copyright-text">Copyright &copy; 2018
              <a href="#">Bookify</a>. All rights reserved.
            </p>
          </div>
          <div class="col-md-6">
            <ul class="theme-copyright-social">
              <li>
                <a class="fa fa-facebook" href="#"></a>
              </li>
              <li>
                <a class="fa fa-google" href="#"></a>
              </li>
              <li>
                <a class="fa fa-twitter" href="#"></a>
              </li>
              <li>
                <a class="fa fa-youtube-play" href="#"></a>
              </li>
              <li>
                <a class="fa fa-instagram" href="#"></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <script src="js/jquery.js"></script>
    <script src="js/moment.js"></script>
    <script src="js/bootstrap.js"></script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDYeBBmgAkyAN_QKjAVOiP_kWZ_eQdadeI&amp;callback=initMap&amp;libraries=places"></script>
    <script src="js/owl-carousel.js"></script>
    <script src="js/blur-area.js"></script>
    <script src="js/icheck.js"></script>
    <script src="js/gmap.js"></script>
    <script src="js/magnific-popup.js"></script>
    <script src="js/ion-range-slider.js"></script>
    <script src="js/sticky-kit.js"></script>
    <script src="js/smooth-scroll.js"></script>
    <script src="js/fotorama.js"></script>
    <script src="js/bs-datepicker.js"></script>
    <script src="js/typeahead.js"></script>
    <script src="js/quantity-selector.js"></script>
    <script src="js/countdown.js"></script>
    <script src="js/window-scroll-action.js"></script>
    <script src="js/fitvid.js"></script>
    <script src="js/youtube-bg.js"></script>
    <script src="js/custom.js"></script>
  </body>

<!-- Mirrored from remtsoy.com/tf_templates/tf-bookify-demo/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 11 Jan 2020 15:39:08 GMT -->
</html>